// Echoes - Project Sekai Rhythm Simulator Engine (Polished Edition)

const KEY_MAP = { 's': 0, 'd': 1, 'f': 2, 'j': 3, 'k': 4, 'l': 5 };
const LANE_COLORS = {
    tap: '#4aa3ff',        // Neon Blue
    critical: '#ffcc00',   // Neon Gold
    flick: '#ff55b8',      // Neon Pink
    hold: '#55ff88'        // Neon Green
};

class EchoesGame {
    constructor() {
        this.canvas = document.getElementById('game-canvas');
        this.ctx = this.canvas.getContext('2d');
        
        // Tracks Geometry (dynamically updated in resizeCanvas)
        this.topY = 0;
        this.bottomY = 0;
        this.topWidth = 0;
        this.bottomWidth = 0;
        this.centerX = 0;
        
        // Game States
        this.isPlaying = false;
        this.isPaused = false;
        this.startTime = 0;
        this.pauseTime = 0;
        this.songDuration = 65; // Seconds
        this.audioContext = null;
        this.customAudioBuffer = null;
        this.audioSource = null;
        this.useSynth = true;
        this.songName = "Echoes (Built-in Synthesizer)";
        
        // Settings & Configurations
        this.speed = 6.0;
        this.autoPlay = false;
        this.bgmVolume = 80;
        this.seVolume = 80;
        this.scrollTime = 1.5; // Calculated from speed
        this.calculateScrollTime();
        
        // Gameplay Variables
        this.score = 0;
        this.combo = 0;
        this.maxCombo = 0;
        this.stats = { perfect: 0, great: 0, good: 0, miss: 0 };
        this.chart = [];
        this.activeNotes = [];
        this.dynamicChart = null; // Dynamically loaded song chart JSON
        this.currentChartUrl = null; // Currently loading chart URL
        this.dataDownloaded = false; // Flag to check if server files are synced
        
        // Parse server base URL from query parameters (for mobile container launcher mapping)
        const urlParams = new URLSearchParams(window.location.search);
        this.serverUrl = (urlParams.get('server') || '').replace(/\/$/, "");
        
        this.perfectWindow = 0.055; // Seconds
        this.greatWindow = 0.105;
        this.goodWindow = 0.165;
        
        // Touch gesture tracking (for flick gesture)
        this.touchStartPoints = {}; // Maps touch identifier to {x, y, time}
        this.mouseStartPoint = null; // For PC mouse flick test
        
        // Hold states
        this.isLaneHeld = Array(6).fill(false);
        this.touchLanes = {};
        this.currentTouches = {}; // Active multi-touch tracking map
        this.keyboardLanesHeld = Array(6).fill(false); // Keyboard hold state
        
        // Audio interpolation sync
        this.lastAudioTime = 0;
        this.lastAudioUpdateSystemTime = 0;
        
        // Visual effects lists
        this.ripples = [];
        this.particles = [];
        this.lineGlows = Array(6).fill(0);
        
        // Background Images
        this.bgImage = new Image();
        this.bgImage.src = 'background.jpg';
        
        this.gameBgImage = new Image();
        this.gameBgImage.src = 'gameplay.jpg';
        this.gameBgImage.onerror = () => {
            // Fallback to start screen background if gameplay.jpg is not uploaded
            this.gameBgImage = this.bgImage;
        };
        
        // Bind UI Events
        this.initUI();
        this.initSfx();
        
        // Resize Handler
        window.addEventListener('resize', () => this.resizeCanvas());
        this.resizeCanvas();

        // Start Startup Loading Sequence
        this.startLoadingSequence();
    }

    // Startup loading bar animation
    startLoadingSequence() {
        const loadingBar = document.getElementById('loading-bar');
        const loadingText = document.getElementById('loading-text');
        let progress = 0;
        
        const loadTimer = setInterval(() => {
            progress += Math.floor(Math.random() * 8) + 2;
            if (progress >= 100) {
                progress = 100;
                clearInterval(loadTimer);
                setTimeout(() => {
                    // Hide loading and show main menu
                    document.getElementById('loading-screen').classList.remove('active');
                    document.getElementById('start-screen').classList.add('active');
                }, 400);
            }
            loadingBar.style.width = `${progress}%`;
            loadingText.textContent = `正在讀取超自然迴響資料... ${progress}%`;
        }, 80);
    }

    calculateScrollTime() {
        // Higher speed = smaller scrollTime (notes fall faster)
        // Speed 6.0 -> 1.5s
        // Speed 10.0 -> 0.9s
        // Speed 2.0 -> 4.5s
        this.scrollTime = 9.0 / this.speed;
    }

    initUI() {
        // Main Cover Screen Game Start Button (Triggers download confirmation modal)
        document.getElementById('main-start-btn').addEventListener('click', () => {
            if (!this.dataDownloaded) {
                document.getElementById('download-confirm-modal').style.display = 'flex';
            } else {
                document.getElementById('start-screen').classList.remove('active');
                document.getElementById('song-select-screen').classList.add('active');
            }
        });

        // Download Confirmation Modal Listeners
        document.getElementById('download-confirm-btn').addEventListener('click', () => {
            document.getElementById('download-confirm-modal').style.display = 'none';
            document.getElementById('start-screen').classList.remove('active');
            document.getElementById('song-select-screen').classList.add('active');
            this.dataDownloaded = true;
            this.loadSongList(true); // Download and sync from server
        });

        document.getElementById('download-cancel-btn').addEventListener('click', () => {
            document.getElementById('download-confirm-modal').style.display = 'none';
            document.getElementById('start-screen').classList.remove('active');
            document.getElementById('song-select-screen').classList.add('active');
            this.dataDownloaded = true;
            this.loadSongList(false); // Play offline (synth only)
        });

        // Song Select Back Button
        document.getElementById('song-select-back-btn').addEventListener('click', () => {
            document.getElementById('song-select-screen').classList.remove('active');
            document.getElementById('start-screen').classList.add('active');
        });

        // Dynamic song list loading on startup (does not query server until prompt resolves)
        this.loadSongList(false);

        // Open Creator Studio page
        const openCreatorBtn = document.getElementById('open-creator-btn');
        if (openCreatorBtn) {
            openCreatorBtn.addEventListener('click', () => {
                window.open('/creator', '_blank');
            });
        }

        const fileInput = document.getElementById('audio-upload');
        const fileNameDisplay = document.getElementById('file-name-display');
        const playCustomBtn = document.getElementById('play-custom-btn');

        if (fileInput && playCustomBtn) {
            fileInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    fileNameDisplay.textContent = file.name;
                    playCustomBtn.disabled = false;
                    playCustomBtn.classList.remove('disabled');
                    
                    // Read audio file
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        const arrayBuffer = event.target.result;
                        this.initAudioContext();
                        this.audioContext.decodeAudioData(arrayBuffer, (decodedBuffer) => {
                            this.customAudioBuffer = decodedBuffer;
                            this.songDuration = decodedBuffer.duration;
                            console.log("Audio Loaded. Duration:", this.songDuration);
                        }, (err) => {
                            alert("音訊解碼失敗，請嘗試其他的 MP3 檔案");
                        });
                    };
                    reader.readAsArrayBuffer(file);
                }
            });

            playCustomBtn.addEventListener('click', () => {
                if (this.customAudioBuffer) {
                    this.useSynth = false;
                    this.songName = fileNameDisplay.textContent.replace(".mp3", "");
                    this.start();
                }
            });
        }

        // Settings Panel toggles
        const settingsScreen = document.getElementById('settings-screen');
        document.getElementById('open-settings-btn').addEventListener('click', () => {
            settingsScreen.classList.add('active');
        });

        document.getElementById('close-settings-btn').addEventListener('click', () => {
            settingsScreen.classList.remove('active');
        });

        // Settings inputs
        const speedSlider = document.getElementById('setting-speed');
        const speedDisplay = document.getElementById('speed-val-display');
        speedSlider.addEventListener('input', (e) => {
            this.speed = parseFloat(e.target.value);
            speedDisplay.textContent = this.speed.toFixed(1);
            this.calculateScrollTime();
        });

        const autoPlayCheckbox = document.getElementById('setting-autoplay');
        autoPlayCheckbox.addEventListener('change', (e) => {
            this.autoPlay = e.target.checked;
        });

        const bgmSlider = document.getElementById('setting-bgm');
        const bgmDisplay = document.getElementById('bgm-val-display');
        bgmSlider.addEventListener('input', (e) => {
            this.bgmVolume = parseInt(e.target.value);
            bgmDisplay.textContent = `${this.bgmVolume}%`;
            if (this.audioElement) {
                this.audioElement.volume = this.bgmVolume / 100;
            }
        });

        const seSlider = document.getElementById('setting-se');
        const seDisplay = document.getElementById('se-val-display');
        seSlider.addEventListener('input', (e) => {
            this.seVolume = parseInt(e.target.value);
            seDisplay.textContent = `${this.seVolume}%`;
        });

        // Gameplay Screen Controls
        document.getElementById('pause-btn').addEventListener('click', () => this.pause());
        document.getElementById('resume-btn').addEventListener('click', () => this.resume());
        document.getElementById('restart-btn').addEventListener('click', () => {
            this.hideOverlay('pause-screen');
            this.start();
        });
        document.getElementById('quit-btn').addEventListener('click', () => this.quit());
        document.getElementById('result-close-btn').addEventListener('click', () => this.quit());

        // Keyboard inputs
        window.addEventListener('keydown', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            const lane = KEY_MAP[e.key.toLowerCase()];
            if (lane !== undefined) {
                this.keyboardLanesHeld[lane] = true;
                this.lineGlows[lane] = 1.0;
                this.triggerHit(lane, true); // Keyboard acts as tap/flick
            }
        });

        window.addEventListener('keyup', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            const lane = KEY_MAP[e.key.toLowerCase()];
            if (lane !== undefined) {
                this.keyboardLanesHeld[lane] = false;
            }
        });

        // Mobile touch inputs (Tracks Flick Gestures & Hold Tracking)
        this.canvas.addEventListener('touchstart', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            e.preventDefault();
            const now = Date.now();
            for (let i = 0; i < e.changedTouches.length; i++) {
                const touch = e.changedTouches[i];
                this.touchStartPoints[touch.identifier] = {
                    x: touch.clientX,
                    y: touch.clientY,
                    time: now
                };
                this.currentTouches[touch.identifier] = {
                    x: touch.clientX,
                    y: touch.clientY
                };
                
                const lane = this.getLaneFromCoordinates(touch.clientX, touch.clientY, false); // strict Y for tap
                if (lane !== null) {
                    this.touchLanes[touch.identifier] = lane;
                    this.lineGlows[lane] = 1.0;
                    this.triggerHit(lane, false); // regular tap check on touch start
                }
            }
        }, { passive: false });

        this.canvas.addEventListener('touchmove', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            e.preventDefault();
            for (let i = 0; i < e.changedTouches.length; i++) {
                const touch = e.changedTouches[i];
                this.currentTouches[touch.identifier] = {
                    x: touch.clientX,
                    y: touch.clientY
                };
                
                // Dynamic slide lane switching
                const oldLane = this.touchLanes[touch.identifier];
                const newLane = this.getLaneFromCoordinates(touch.clientX, touch.clientY, true); // wide Y for sliding
                
                if (newLane !== null && newLane !== oldLane) {
                    this.touchLanes[touch.identifier] = newLane;
                    this.lineGlows[newLane] = 1.0;
                }
            }
        }, { passive: false });

        const releaseTouch = (touch) => {
            delete this.currentTouches[touch.identifier];
            const lane = this.touchLanes[touch.identifier];
            if (lane !== undefined) {
                delete this.touchLanes[touch.identifier];
            }
            
            const start = this.touchStartPoints[touch.identifier];
            if (start) {
                const dy = touch.clientY - start.y;
                const dt = Date.now() - start.time;
                if (dy < -30 && dt < 240) {
                    const lane = this.getLaneFromCoordinates(touch.clientX, touch.clientY, false) 
                               || this.getLaneFromCoordinates(start.x, start.y, false);
                      if (lane !== null) {
                          this.triggerHit(lane, true); // Trigger Flick Hit!
                      }
                }
                delete this.touchStartPoints[touch.identifier];
            }
        };

        this.canvas.addEventListener('touchend', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            for (let i = 0; i < e.changedTouches.length; i++) {
                releaseTouch(e.changedTouches[i]);
            }
        }, { passive: false });

        this.canvas.addEventListener('touchcancel', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            for (let i = 0; i < e.changedTouches.length; i++) {
                releaseTouch(e.changedTouches[i]);
            }
        }, { passive: false });

        // PC Mouse Click & Flick Mockup
        this.canvas.addEventListener('mousedown', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            this.mouseStartPoint = {
                x: e.clientX,
                y: e.clientY,
                time: Date.now()
            };
            const lane = this.getLaneFromCoordinates(e.clientX, e.clientY, false); // strict Y for tap
            if (lane !== null) {
                this.lineGlows[lane] = 1.0;
                this.triggerHit(lane, false); // Tap on click down
            }
        });

        this.canvas.addEventListener('mouseup', (e) => {
            if (!this.isPlaying || this.isPaused) return;
            if (this.mouseStartPoint) {
                const dy = e.clientY - this.mouseStartPoint.y;
                const dt = Date.now() - this.mouseStartPoint.time;
                if (dy < -30 && dt < 240) {
                    const lane = this.getLaneFromCoordinates(e.clientX, e.clientY, false) 
                               || this.getLaneFromCoordinates(this.mouseStartPoint.x, this.mouseStartPoint.y, false);
                    if (lane !== null) {
                        this.triggerHit(lane, true); // Trigger Flick Hit on swipe release
                    }
                }
                this.mouseStartPoint = null;
            }
        });

        this.canvas.addEventListener('mouseleave', () => {
            this.mouseStartPoint = null;
        });
    }

    initSfx() {
        this.sfxPools = {};
        const sfxFiles = {
            perfect: 'sfx/se_live_perfect.mp3',
            great: 'sfx/se_live_great.mp3',
            good: 'sfx/se_live_good.mp3',
            flick: 'sfx/se_live_flick.mp3',
            critical: 'gold_sfx/黃金擊中.mp3',
            hold: 'sfx/se_live_long.mp3',
            tap: 'sfx/se_live_tap.mp3'
        };

        for (let key in sfxFiles) {
            this.sfxPools[key] = [];
            for (let i = 0; i < 6; i++) {
                const audio = new Audio(sfxFiles[key]);
                audio.preload = 'auto';
                this.sfxPools[key].push({
                    audio: audio
                });
            }
            this.sfxPools[key + '_ptr'] = 0;
        }
    }

    async loadSongList(fetchFromServer = false) {
        const container = document.getElementById('song-list-container');
        if (!container) return;
        container.innerHTML = '<div style="color: #a6a6d6; text-align: center; width: 100%;">正在載入關卡清單...</div>';
        
        const defaultSongs = [
            {
                id: 'synth',
                title: '內建合成器測試曲 (本地離線)',
                audio: '',
                chart: '',
                cover: '🎹',
                difficulty: 'NORMAL',
                level: 12,
                isSynth: true,
                duration: 65
            }
        ];
        
        let songs = defaultSongs;
        
        if (fetchFromServer) {
            try {
                const targetUrl = this.serverUrl ? `${this.serverUrl}/songs.json` : '/api/songs';
                const response = await fetch(targetUrl);
                if (response.ok) {
                    const serverSongs = await response.json();
                    if (Array.isArray(serverSongs) && serverSongs.length > 0) {
                        // Display uploaded dynamic songs first, followed by built-in synth
                        songs = serverSongs.concat(defaultSongs);
                    }
                }
            } catch (e) {
                console.log("Offline mode or server unavailable. Using default song list:", e);
            }
        }
        
        container.innerHTML = '';
        
        // If we synced from server but the directory is empty, show a helpful tip
        if (fetchFromServer && songs.length === 1 && songs[0].id === 'synth') {
            const hint = document.createElement('div');
            hint.style.cssText = "color: #a6a6d6; text-align: center; width: 100%; margin: 15px 0; font-size: 0.9rem; line-height: 1.6;";
            hint.innerHTML = "💡 目前伺服器關卡夾為空，無任何上傳關卡。<br>你可以點擊右上角「🎨 關卡投稿」進行創作與發布！";
            container.appendChild(hint);
        } else if (!fetchFromServer) {
            const hint = document.createElement('div');
            hint.style.cssText = "color: #a6a6d6; text-align: center; width: 100%; margin: 15px 0; font-size: 0.9rem; line-height: 1.6;";
            hint.innerHTML = "💡 處於離線預覽模式。如需同步伺服器歌曲，<br>請重新載入並點擊「確認下載」以加載最新資料。";
            container.appendChild(hint);
        }
        
        songs.forEach(song => {
            const card = document.createElement('div');
            card.className = 'song-card';
            card.id = `song-card-${song.id}`;
            
            if (song.isSynth) {
                card.innerHTML = `
                    <div class="song-thumb-synth" style="display: flex; align-items: center; justify-content: center; background: rgba(255, 255, 255, 0.05); border: 1px dashed rgba(255, 255, 255, 0.2); font-size: 1.8rem; border-radius: 8px; width: 60px; height: 60px; margin-right: 15px;">🎹</div>
                    <div class="song-details" style="display: flex; flex-direction: column; justify-content: center; flex: 1;">
                        <span class="song-title" style="font-weight: 700; font-size: 1.1rem; color: #ffffff; margin-bottom: 2px;">${song.title}</span>
                        <span class="song-difficulty normal" style="font-size: 0.8rem; font-weight: 600; padding: 2px 8px; border-radius: 4px; display: inline-block; width: max-content; background: rgba(0, 240, 255, 0.15); color: #00ffff;">${song.difficulty} Lv.${song.level}</span>
                    </div>
                `;
                card.addEventListener('click', () => {
                    this.useSynth = true;
                    this.songName = song.title;
                    this.songDuration = song.duration || 65;
                    this.start();
                });
            } else {
                let coverSrc = song.cover;
                if (this.serverUrl && song.cover.startsWith('/')) {
                    coverSrc = this.serverUrl + song.cover;
                }
                
                card.innerHTML = `
                    <img src="${coverSrc}" class="song-thumb" style="width: 60px; height: 60px; border-radius: 8px; object-fit: cover; margin-right: 15px;" onerror="this.src='level1_thumb.jpg'">
                    <div class="song-details" style="display: flex; flex-direction: column; justify-content: center; flex: 1;">
                        <span class="song-title" style="font-weight: 700; font-size: 1.1rem; color: #ffffff; margin-bottom: 2px;">${song.title}</span>
                        <span class="song-difficulty ${song.difficulty.toLowerCase()}" style="font-size: 0.8rem; font-weight: 600; padding: 2px 8px; border-radius: 4px; display: inline-block; width: max-content; background: ${song.difficulty.toLowerCase() === 'expert' ? 'rgba(255, 0, 127, 0.15)' : 'rgba(0, 240, 255, 0.15)'}; color: ${song.difficulty.toLowerCase() === 'expert' ? '#ff007f' : '#00ffff'};">${song.difficulty} Lv.${song.level}</span>
                    </div>
                `;
                card.addEventListener('click', () => {
                    this.useSynth = false;
                    
                    let audioPath = song.audio;
                    let chartPath = song.chart;
                    let bgPath = 'gameplay.jpg'; // Default background
                    
                    if (song.background) {
                        bgPath = song.background;
                    }
                    
                    if (this.serverUrl) {
                        if (song.audio && song.audio.startsWith('/')) audioPath = this.serverUrl + song.audio;
                        if (song.chart && song.chart.startsWith('/')) chartPath = this.serverUrl + song.chart;
                        if (song.background && song.background.startsWith('/')) bgPath = this.serverUrl + song.background;
                    }
                    
                    // Dynamically load song-specific background image
                    this.gameBgImage = new Image();
                    this.gameBgImage.src = bgPath;
                    this.gameBgImage.onerror = () => {
                        this.gameBgImage = this.bgImage; // Fallback to start screen background
                    };
                    
                    this.loadAndStartSong(audioPath, song.title, song.duration || 45, chartPath);
                });
            }
            container.appendChild(card);
        });
    }

    loadAndStartSong(audioUrl, songName, duration, chartUrl) {
        const loadingScreen = document.getElementById('loading-screen');
        const loadingText = document.getElementById('loading-text');
        const loadingBar = document.getElementById('loading-bar');
        loadingScreen.classList.add('active');
        loadingBar.style.width = '0%';
        loadingText.textContent = "正在載入音訊檔案...";
        
        this.initAudioContext();
        
        // Use standard HTML5 Audio to avoid local file CORS restrictions on PC browsers
        if (this.audioElement) {
            this.audioElement.pause();
        }
        this.audioElement = new Audio(audioUrl);
        this.audioElement.volume = this.bgmVolume / 100;
        
        // Wait for metadata to load to make sure it plays
        this.audioElement.addEventListener('canplaythrough', () => {
            loadingBar.style.width = '50%';
            loadingText.textContent = "正在載入譜面資料...";
        }, { once: true });
        
        this.audioElement.addEventListener('error', (e) => {
            console.error("Audio loading error:", e);
        });

        this.currentChartUrl = chartUrl;

        // Simulate progress bar quickly
        let progress = 0;
        const interval = setInterval(async () => {
            progress += 10;
            if (progress > 90 && !this.audioElement.duration) {
                progress = 90; // Wait for audio initialization
            }
            loadingBar.style.width = `${progress}%`;
            if (progress >= 100) {
                clearInterval(interval);
                
                // Fetch dynamic chart if provided
                if (this.currentChartUrl) {
                    try {
                        const response = await fetch(this.currentChartUrl);
                        if (response.ok) {
                            const text = await response.text();
                            
                            // Support BOTH JSON and our simplified space-separated text format (.txt)
                            if (this.currentChartUrl.toLowerCase().endsWith('.txt') || !text.trim().startsWith('[')) {
                                const lines = text.split('\n');
                                const parsedChart = [];
                                for (let line of lines) {
                                    line = line.trim();
                                    if (!line || line.startsWith('#') || line.startsWith('//')) continue;
                                    const parts = line.split(/\s+/);
                                    if (parts.length >= 3) {
                                        const time = parseFloat(parts[0]);
                                        const lane = parseInt(parts[1]);
                                        const type = parts[2].toLowerCase();
                                        const note = { time, lane, type };
                                        if (type === 'hold' && parts.length >= 4) {
                                            note.duration = parseFloat(parts[3]);
                                        }
                                        parsedChart.push(note);
                                    }
                                }
                                this.dynamicChart = parsedChart;
                                console.log("Custom text-based chart parsed successfully!", this.dynamicChart);
                            } else {
                                const fetchedChart = JSON.parse(text);
                                if (Array.isArray(fetchedChart)) {
                                    this.dynamicChart = fetchedChart;
                                    console.log("JSON chart loaded successfully!");
                                }
                            }
                        }
                    } catch (e) {
                        console.warn("Failed to load dynamic chart, falling back:", e);
                        this.dynamicChart = null;
                    }
                } else {
                    this.dynamicChart = null;
                }

                setTimeout(() => {
                    this.useSynth = false;
                    this.songName = songName;
                    this.songDuration = duration;
                    loadingScreen.classList.remove('active');
                    this.start();
                }, 400);
            }
        }, 60);
    }

    resizeCanvas() {
        const container = document.getElementById('game-container');
        const w = container.clientWidth;
        const h = container.clientHeight;
        
        this.canvas.width = w;
        this.canvas.height = h;

        this.centerX = w / 2;
        this.topY = h * 0.18;      
        this.bottomY = h * 0.84;   

        this.bottomWidth = Math.min(w * 0.85, h * 1.25, 960); 
        this.topWidth = this.bottomWidth * 0.38; 
    }

    getLaneFromCoordinates(clientX, clientY, isHolding) {
        const rect = this.canvas.getBoundingClientRect();
        const x = clientX - rect.left;
        const y = clientY - rect.top;
        
        // Visual boundary limits (wider Y-tolerance when holding to prevent accidental breaks)
        const yMin = isHolding ? (this.bottomY - 350) : (this.bottomY - 110);
        const yMax = isHolding ? (this.bottomY + 250) : (this.bottomY + 110);
        
        if (y < yMin || y > yMax) return null;

        const wL = this.centerX - this.bottomWidth / 2;
        const wR = this.centerX + this.bottomWidth / 2;
        
        if (x < wL || x > wR) return null;
        
        const relativeX = x - wL;
        const laneWidth = this.bottomWidth / 6;
        return Math.floor(relativeX / laneWidth);
    }

    initAudioContext() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
    }

    loadChart() {
        if (this.dynamicChart) {
            this.chart = this.dynamicChart;
            return;
        }
        // Embedded chart to bypass local file CORS constraints on PC browsers
        this.chart = [
            { "time": 1.5, "lane": 2, "type": "tap" },
            { "time": 2.0, "lane": 3, "type": "tap" },
            { "time": 2.5, "lane": 1, "type": "tap" },
            { "time": 2.5, "lane": 4, "type": "tap" },
            { "time": 3.2, "lane": 2, "type": "critical" },
            { "time": 3.8, "lane": 3, "type": "flick" },
            { "time": 4.5, "lane": 1, "type": "hold", "duration": 1.5 },
            { "time": 4.5, "lane": 4, "type": "hold", "duration": 1.5 },
            { "time": 6.5, "lane": 2, "type": "tap" },
            { "time": 7.0, "lane": 3, "type": "tap" },
            { "time": 7.5, "lane": 0, "type": "tap" },
            { "time": 7.5, "lane": 5, "type": "tap" },
            { "time": 8.2, "lane": 2, "type": "critical" },
            { "time": 8.8, "lane": 3, "type": "flick" },
            { "time": 10.0, "lane": 2, "type": "hold", "duration": 2.0 },
            { "time": 10.5, "lane": 3, "type": "tap" },
            { "time": 11.2, "lane": 4, "type": "tap" },
            { "time": 12.0, "lane": 1, "type": "flick" },
            { "time": 13.0, "lane": 2, "type": "tap" },
            { "time": 13.5, "lane": 3, "type": "tap" },
            { "time": 14.0, "lane": 1, "type": "tap" },
            { "time": 14.5, "lane": 4, "type": "tap" },
            { "time": 15.0, "lane": 0, "type": "critical" },
            { "time": 15.0, "lane": 5, "type": "critical" },
            { "time": 16.0, "lane": 2, "type": "hold", "duration": 3.0 },
            { "time": 16.5, "lane": 4, "type": "tap" },
            { "time": 17.5, "lane": 1, "type": "tap" },
            { "time": 18.0, "lane": 3, "type": "flick" },
            { "time": 19.5, "lane": 2, "type": "tap" },
            { "time": 20.0, "lane": 3, "type": "tap" },
            { "time": 20.5, "lane": 1, "type": "tap" },
            { "time": 20.5, "lane": 4, "type": "tap" },
            { "time": 21.2, "lane": 2, "type": "critical" },
            { "time": 21.8, "lane": 3, "type": "flick" },
            { "time": 22.5, "lane": 1, "type": "hold", "duration": 1.5 },
            { "time": 22.5, "lane": 4, "type": "hold", "duration": 1.5 },
            { "time": 24.5, "lane": 2, "type": "tap" },
            { "time": 25.0, "lane": 3, "type": "tap" },
            { "time": 25.5, "lane": 0, "type": "tap" },
            { "time": 25.5, "lane": 5, "type": "tap" },
            { "time": 26.2, "lane": 2, "type": "critical" },
            { "time": 26.8, "lane": 3, "type": "flick" },
            { "time": 28.0, "lane": 2, "type": "hold", "duration": 2.0 },
            { "time": 28.5, "lane": 3, "type": "tap" },
            { "time": 29.2, "lane": 4, "type": "tap" },
            { "time": 30.0, "lane": 1, "type": "flick" },
            { "time": 31.0, "lane": 2, "type": "tap" },
            { "time": 31.5, "lane": 3, "type": "tap" },
            { "time": 32.0, "lane": 1, "type": "tap" },
            { "time": 32.5, "lane": 4, "type": "tap" },
            { "time": 33.0, "lane": 0, "type": "critical" },
            { "time": 33.0, "lane": 5, "type": "critical" },
            { "time": 34.0, "lane": 2, "type": "hold", "duration": 3.0 },
            { "time": 34.5, "lane": 4, "type": "tap" },
            { "time": 35.5, "lane": 1, "type": "tap" },
            { "time": 36.0, "lane": 3, "type": "flick" },
            { "time": 37.5, "lane": 1, "type": "tap" },
            { "time": 37.8, "lane": 2, "type": "tap" },
            { "time": 38.1, "lane": 3, "type": "tap" },
            { "time": 38.4, "lane": 4, "type": "tap" },
            { "time": 39.0, "lane": 2, "type": "flick" },
            { "time": 39.0, "lane": 3, "type": "flick" },
            { "time": 40.0, "lane": 0, "type": "hold", "duration": 4.0 },
            { "time": 40.5, "lane": 5, "type": "hold", "duration": 4.0 },
            { "time": 41.5, "lane": 2, "type": "tap" },
            { "time": 42.0, "lane": 3, "type": "tap" },
            { "time": 42.5, "lane": 1, "type": "critical" },
            { "time": 42.5, "lane": 4, "type": "critical" }
        ];
        
        this.activeNotes = JSON.parse(JSON.stringify(this.chart));
        this.activeNotes.forEach(note => {
            if (note.type === 'critical') {
                note.type = 'tap';
            }
            note.hit = false;
            note.missed = false;
        });
    }

    start() {
        this.initAudioContext();
        this.loadChart();
        
        this.score = 0;
        this.combo = 0;
        this.maxCombo = 0;
        this.stats = { perfect: 0, great: 0, good: 0, miss: 0 };
        this.ripples = [];
        this.particles = [];
        this.lineGlows.fill(0);
        
        document.getElementById('score-val').textContent = "000000";
        document.getElementById('current-song-name').textContent = this.songName;
        
        document.getElementById('start-screen').classList.remove('active');
        document.getElementById('song-select-screen').classList.remove('active');
        document.getElementById('gameplay-screen').classList.add('active');
        
        this.isPlaying = true;
        this.isPaused = false;
        
        if (this.useSynth) {
            this.startTime = this.audioContext.currentTime;
            this.startSynth();
        } else if (this.audioElement) {
            this.audioElement.currentTime = 0;
            this.audioElement.volume = this.bgmVolume / 100;
            
            if (this.audioContext && this.audioContext.state === 'suspended') {
                this.audioContext.resume();
            }
            
            this.audioElement.play().catch(err => {
                console.error("Audio element play failed:", err);
            });
        }
        
        requestAnimationFrame((time) => this.loop(time));
    }

    playAudioBuffer(offset) {
        if (this.audioSource) {
            try { this.audioSource.stop(); } catch(e) {}
        }
        this.audioSource = this.audioContext.createBufferSource();
        this.audioSource.buffer = this.customAudioBuffer;
        
        // BGM Volume gain node
        const gainNode = this.audioContext.createGain();
        gainNode.gain.setValueAtTime(this.bgmVolume / 100, this.audioContext.currentTime);
        
        this.audioSource.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        this.audioSource.start(0, offset);
    }

    // Play tap sound effect using Web Audio oscillator (Synthesized SE)
    playHitSound(type) {
        if (this.seVolume === 0) return;
        
        let sfxKey = 'perfect';
        if (type === 'flick') sfxKey = 'flick';
        else if (type === 'critical') sfxKey = 'critical';
        else if (type === 'hold') sfxKey = 'hold';
        else if (type === 'tap_empty') sfxKey = 'tap';

        const pool = this.sfxPools[sfxKey];
        if (!pool) return;
        
        const ptrKey = sfxKey + '_ptr';
        const ptr = this.sfxPools[ptrKey];
        const audioObj = pool[ptr].audio;
        
        this.sfxPools[ptrKey] = (ptr + 1) % pool.length;
        
        // Android WebView Optimization:
        // Resetting currentTime=0 on mobile Chrome/WebView forces media player buffer re-seeking,
        // which incurs a ~100ms lag. Only reset if the element is currently playing.
        if (audioObj.currentTime > 0 && !audioObj.paused && !audioObj.ended) {
            audioObj.currentTime = 0;
        }
        audioObj.volume = this.seVolume / 100;
        audioObj.play().catch(e => {
            console.warn("SFX play blocked:", e);
        });
    }

    playHoldSfx(note) {
        if (this.seVolume === 0) return;
        
        this.stopHoldSfx(note);
        
        const pool = this.sfxPools['hold'];
        const ptrKey = 'hold_ptr';
        const ptr = this.sfxPools[ptrKey];
        const audioObj = pool[ptr].audio;
        
        this.sfxPools[ptrKey] = (ptr + 1) % pool.length;
        
        audioObj.loop = true;
        if (audioObj.currentTime > 0 && !audioObj.paused && !audioObj.ended) {
            audioObj.currentTime = 0;
        }
        audioObj.volume = this.seVolume / 100;
        audioObj.play().catch(e => console.warn("Hold SFX play blocked:", e));
        
        note.audio = audioObj; // Store reference on note itself!
    }

    stopHoldSfx(note) {
        if (note && note.audio) {
            note.audio.pause();
            note.audio.currentTime = 0;
            note.audio.loop = false;
            note.audio = null;
        }
    }

    startSynth() {
        this.synthPlaying = true;
        this.synthBeats = [];
        const bpm = 125;
        const beatDuration = 60 / bpm;
        
        const melody = [
            'E4', 'G4', 'A4', 'B4', 'A4', 'G4', 'E4', 'D4',
            'E4', 'G4', 'A4', 'B4', 'E5', 'D5', 'B4', 'A4',
            'E4', 'G4', 'A4', 'B4', 'A4', 'G4', 'E4', 'D4',
            'G4', 'A4', 'B4', 'A4', 'G4', 'E4', 'D4', 'E4'
        ];

        const getFrequency = (note) => {
            const notesList = {
                'D4': 293.66, 'E4': 329.63, 'G4': 392.00, 'A4': 440.00,
                'B4': 493.88, 'D5': 587.33, 'E5': 659.25
            };
            return notesList[note] || 440.00;
        };

        const scheduleBeat = (time, index) => {
            if (!this.isPlaying || this.isPaused || !this.synthPlaying) return;
            
            const volumeMultiplier = this.bgmVolume / 100;

            // 1. Kick drum
            const oscKick = this.audioContext.createOscillator();
            const gainKick = this.audioContext.createGain();
            oscKick.connect(gainKick);
            gainKick.connect(this.audioContext.destination);
            
            oscKick.frequency.setValueAtTime(140, time);
            oscKick.frequency.exponentialRampToValueAtTime(0.01, time + 0.15);
            gainKick.gain.setValueAtTime(0.35 * volumeMultiplier, time);
            gainKick.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
            
            oscKick.start(time);
            oscKick.stop(time + 0.16);

            // 2. High Hat
            if (index % 2 === 1) {
                const bufferSize = this.audioContext.sampleRate * 0.05;
                const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
                const data = buffer.getChannelData(0);
                for (let i = 0; i < bufferSize; i++) {
                    data[i] = Math.random() * 2 - 1;
                }
                const noiseNode = this.audioContext.createBufferSource();
                noiseNode.buffer = buffer;
                const filter = this.audioContext.createBiquadFilter();
                filter.type = 'highpass';
                filter.frequency.setValueAtTime(7000, time);
                
                const gainNoise = this.audioContext.createGain();
                gainNoise.gain.setValueAtTime(0.05 * volumeMultiplier, time);
                gainNoise.gain.exponentialRampToValueAtTime(0.001, time + 0.04);
                
                noiseNode.connect(filter);
                filter.connect(gainNoise);
                gainNoise.connect(this.audioContext.destination);
                noiseNode.start(time);
            }

            // 3. Lead melody
            const noteIndex = Math.floor(index / 2) % melody.length;
            if (index % 2 === 0) {
                const oscMelody = this.audioContext.createOscillator();
                const gainMelody = this.audioContext.createGain();
                oscMelody.type = 'triangle';
                oscMelody.frequency.setValueAtTime(getFrequency(melody[noteIndex]), time);
                
                oscMelody.connect(gainMelody);
                gainMelody.connect(this.audioContext.destination);
                
                gainMelody.gain.setValueAtTime(0.1 * volumeMultiplier, time);
                gainMelody.gain.exponentialRampToValueAtTime(0.001, time + beatDuration * 1.8);
                
                oscMelody.start(time);
                oscMelody.stop(time + beatDuration * 2);
            }

            const nextTime = time + beatDuration;
            const timeoutId = setTimeout(() => scheduleBeat(nextTime, index + 1), (nextTime - this.audioContext.currentTime) * 1000);
            this.synthBeats.push(timeoutId);
        };

        scheduleBeat(this.audioContext.currentTime + 0.2, 0);
    }

    stopSynth() {
        this.synthPlaying = false;
        if (this.synthBeats) {
            this.synthBeats.forEach(id => clearTimeout(id));
            this.synthBeats = [];
        }
    }

    getElapsedTime() {
        if (!this.isPlaying) return 0;
        if (this.useSynth) {
            if (this.isPaused) return this.pauseTime - this.startTime;
            return this.audioContext.currentTime - this.startTime;
        } else {
            if (!this.audioElement) return 0;
            if (this.isPaused) return this.pauseTime;
            
            const now = performance.now();
            const audioTime = this.audioElement.currentTime;
            
            if (audioTime !== this.lastAudioTime) {
                this.lastAudioTime = audioTime;
                this.lastAudioUpdateSystemTime = now;
            }
            
            const elapsedSinceUpdate = (now - this.lastAudioUpdateSystemTime) / 1000;
            
            // Capped at 0.15s to prevent any potential drift issues
            return audioTime + Math.min(elapsedSinceUpdate, 0.15);
        }
    }

    pause() {
        if (this.isPaused || !this.isPlaying) return;
        this.isPaused = true;
        this.pauseTime = this.getElapsedTime();
        
        if (this.useSynth) {
            this.stopSynth();
        } else if (this.audioElement) {
            this.audioElement.pause();
        }
        
        if (this.activeNotes) {
            for (let note of this.activeNotes) {
                this.stopHoldSfx(note);
            }
        }
        
        this.showOverlay('pause-screen');
    }

    resume() {
        if (!this.isPaused || !this.isPlaying) return;
        this.isPaused = false;
        this.initAudioContext();
        
        // Reset interpolation clocks on resume
        this.lastAudioTime = 0;
        this.lastAudioUpdateSystemTime = 0;
        
        if (this.useSynth) {
            const pausedDuration = this.audioContext.currentTime - this.pauseTime;
            this.startTime += pausedDuration;
            this.startSynth();
        } else if (this.audioElement) {
            this.audioElement.play().catch(e => console.error(e));
        }
        
        this.hideOverlay('pause-screen');
        requestAnimationFrame((time) => this.loop(time));
    }

    quit() {
        this.isPlaying = false;
        this.isPaused = false;
        this.stopSynth();
        if (this.audioElement) {
            this.audioElement.pause();
            this.audioElement = null;
        }
        
        if (this.activeNotes) {
            for (let note of this.activeNotes) {
                this.stopHoldSfx(note);
            }
        }
        
        this.hideOverlay('pause-screen');
        this.hideOverlay('result-screen');
        
        document.getElementById('gameplay-screen').classList.remove('active');
        document.getElementById('song-select-screen').classList.add('active');
    }

    showOverlay(id) {
        document.getElementById(id).classList.add('active');
    }

    hideOverlay(id) {
        document.getElementById(id).classList.remove('active');
    }

    getNotePosition(lane, t) {
        const tRender = t * t; 
        const wL = this.centerX - this.topWidth/2 + tRender * ((this.centerX - this.bottomWidth/2) - (this.centerX - this.topWidth/2));
        const wR = this.centerX + this.topWidth/2 + tRender * ((this.centerX + this.bottomWidth/2) - (this.centerX + this.topWidth/2));
        const wTrack = wR - wL;

        const wLane = wTrack / 6;
        const xLeft = wL + lane * wLane;
        const width = wLane;
        
        const y = this.topY + tRender * (this.bottomY - this.topY);
        
        return { x: xLeft, y: y, width: width };
    }

    triggerHit(lane, isFlickGesture) {
        if (this.autoPlay) return;

        const currentTime = this.getElapsedTime();
        let hitNote = null;
        let minDiff = Infinity;

        for (let note of this.activeNotes) {
            if (note.lane !== lane || note.hit || note.missed) continue;
            
            const diff = Math.abs(currentTime - note.time);
            if (diff < this.goodWindow && diff < minDiff) {
                minDiff = diff;
                hitNote = note;
            }
        }

        if (hitNote) {
            if (hitNote.type === 'flick' && !isFlickGesture) {
                return; 
            }
            
            hitNote.hit = true;
            this.playHitSound(hitNote.type);
            this.handleRating(minDiff, hitNote);
            this.spawnRipple(lane, hitNote.type);

            if (hitNote.type === 'hold') {
                hitNote.holding = true;
                this.playHoldSfx(hitNote);
            }
        } else {
            this.spawnRipple(lane, 'tap');
            this.playHitSound('tap_empty');
        }
    }

    triggerHitAuto(lane, type) {
        this.playHitSound(type);
        this.spawnRipple(lane, type);
        this.lineGlows[lane] = 1.0;
        
        // Auto hits are always PERFECT
        this.stats.perfect++;
        this.score += 1000;
        this.combo++;
        this.maxCombo = Math.max(this.maxCombo, this.combo);
        
        this.showJudgmentText("PERFECT", "perfect-text");
        this.updateHUD();
    }

    spawnRipple(lane, type) {
        const pos = this.getNotePosition(lane, 1.0);
        const x = pos.x + pos.width / 2;
        const y = this.bottomY;
        
        // Ripple wave
        this.ripples.push({
            x: x,
            y: y,
            radius: 8,
            maxRadius: 105,
            alpha: 1.0,
            speed: 5.0
        });

        // Sparks color matches note type
        const color = LANE_COLORS[type] || '#ffffff';

        for (let i = 0; i < 7; i++) {
            const angle = Math.random() * Math.PI - Math.PI;
            const speed = 2.5 + Math.random() * 4.5;
            this.particles.push({
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 1.5,
                radius: 2.5 + Math.random() * 3.5,
                alpha: 1.0,
                color: color
            });
        }
    }

    spawnHoldSparks(lane) {
        if (Math.random() > 0.45) return; 
        const pos = this.getNotePosition(lane, 1.0);
        const x = pos.x + pos.width / 2 + (Math.random() * 24 - 12);
        const y = this.bottomY;
        this.particles.push({
            x: x,
            y: y,
            vx: (Math.random() - 0.5) * 2.5,
            vy: -1.0 - Math.random() * 2.5,
            radius: 1.5 + Math.random() * 2.0,
            alpha: 0.8,
            color: LANE_COLORS.hold
        });
    }

    handleRating(diff, note) {
        let rating = "";
        let ratingClass = "";
        let points = 0;

        if (diff <= this.perfectWindow) {
            rating = "PERFECT";
            ratingClass = "perfect-text";
            this.stats.perfect++;
            points = 1000;
            this.combo++;
        } else if (diff <= this.greatWindow) {
            rating = "GREAT";
            ratingClass = "great-text";
            this.stats.great++;
            points = 750;
            this.combo++;
        } else {
            rating = "GOOD";
            ratingClass = "good-text";
            this.stats.good++;
            points = 500;
            this.combo++;
        }

        this.score += points;
        this.maxCombo = Math.max(this.maxCombo, this.combo);
        
        this.showJudgmentText(rating, ratingClass);
        this.updateHUD();
    }

    triggerMiss() {
        this.stats.miss++;
        this.combo = 0;
        this.showJudgmentText("MISS", "miss-text");
        this.updateHUD();
    }

    showJudgmentText(text, className) {
        const display = document.getElementById('judgment-display');
        display.className = className;
        display.textContent = text;
        
        display.classList.remove('animate');
        void display.offsetWidth; 
        display.classList.add('animate');
    }

    updateHUD() {
        document.getElementById('score-val').textContent = String(this.score).padStart(6, '0');
        
        const comboContainer = document.getElementById('combo-container');
        const comboNumber = document.getElementById('combo-number');
        
        if (this.combo >= 3) {
            comboNumber.textContent = this.combo;
            comboContainer.classList.add('active');
        } else {
            comboContainer.classList.remove('active');
        }
    }

    showResult() {
        this.stopSynth();
        
        if (this.activeNotes) {
            for (let note of this.activeNotes) {
                this.stopHoldSfx(note);
            }
        }
        
        document.getElementById('res-max-combo').textContent = this.maxCombo;
        document.getElementById('res-perfect').textContent = this.stats.perfect;
        document.getElementById('res-great').textContent = this.stats.great;
        document.getElementById('res-good').textContent = this.stats.good;
        document.getElementById('res-miss').textContent = this.stats.miss;
        document.getElementById('res-score').textContent = String(this.score).padStart(6, '0');
        
        this.showOverlay('result-screen');
    }

    // --- RENDER FUNCTIONS ---
    drawBackground() {
        const cw = this.canvas.width;
        const ch = this.canvas.height;
        
        // Select active background: gameBgImage for Level 1, bgImage for Synth Demo
        const img = this.useSynth ? this.bgImage : (this.gameBgImage || this.bgImage);
        const iw = img.width || 1920;
        const ih = img.height || 1080;
        
        // Aspect-ratio cover calculation
        const rSrc = iw / ih;
        const rDest = cw / ch;
        let sx, sy, sw, sh;
        
        if (rSrc > rDest) {
            sh = ih;
            sw = sh * rDest;
            sx = (iw - sw) / 2;
            sy = 0;
        } else {
            sw = iw;
            sh = sw / rDest;
            sx = 0;
            sy = (ih - sh) / 2;
        }
        
        this.ctx.drawImage(img, sx, sy, sw, sh, 0, 0, cw, ch);
        
        // Dark translucent overlay
        this.ctx.fillStyle = "rgba(8, 8, 16, 0.74)";
        this.ctx.fillRect(0, 0, cw, ch);
        
        // Vignette radial glow
        const grad = this.ctx.createRadialGradient(this.centerX, this.topY, 150, this.centerX, this.topY, ch * 0.85);
        grad.addColorStop(0, 'rgba(140, 140, 255, 0.18)');
        grad.addColorStop(1, 'transparent');
        this.ctx.fillStyle = grad;
        this.ctx.fillRect(0, 0, cw, ch);
    }

    drawTrack() {
        // 1. Board background trapezoid
        this.ctx.beginPath();
        this.ctx.moveTo(this.centerX - this.topWidth/2, this.topY);
        this.ctx.lineTo(this.centerX + this.topWidth/2, this.topY);
        this.ctx.lineTo(this.centerX + this.bottomWidth/2, this.bottomY);
        this.ctx.lineTo(this.centerX - this.bottomWidth/2, this.bottomY);
        this.ctx.closePath();
        this.ctx.fillStyle = 'rgba(12, 12, 24, 0.78)';
        this.ctx.fill();

        // 2. Vertical dividers
        this.ctx.lineWidth = 1.5;
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
        for (let i = 1; i < 6; i++) {
            const pTop = this.getNotePosition(i, 0.0);
            const pBot = this.getNotePosition(i, 1.0);
            this.ctx.beginPath();
            this.ctx.moveTo(pTop.x, this.topY);
            this.ctx.lineTo(pBot.x, this.bottomY);
            this.ctx.stroke();
        }

        // 3. Glowing neon borders
        const pTL = this.getNotePosition(0, 0.0);
        const pBL = this.getNotePosition(0, 1.0);
        const pTR = this.getNotePosition(6, 0.0);
        const pBR = this.getNotePosition(6, 1.0);

        this.ctx.save();
        this.ctx.lineWidth = 4.0;
        this.ctx.strokeStyle = 'rgba(140, 140, 255, 0.65)';
        this.ctx.shadowBlur = 12;
        this.ctx.shadowColor = '#8c8cff';
        
        // Left
        this.ctx.beginPath();
        this.ctx.moveTo(pTL.x, this.topY);
        this.ctx.lineTo(pBL.x, this.bottomY);
        this.ctx.stroke();

        // Right
        this.ctx.beginPath();
        this.ctx.moveTo(pTR.x, this.topY);
        this.ctx.lineTo(pBR.x, this.bottomY);
        this.ctx.stroke();
        this.ctx.restore();

        // 4. Horizontal ticks
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
        this.ctx.lineWidth = 1.0;
        const curTime = this.getElapsedTime();
        const tickSpacing = 0.2;
        const firstTickTime = curTime - (curTime % tickSpacing);
        
        for (let t = firstTickTime; t < curTime + this.scrollTime; t += tickSpacing) {
            const timeDiff = t - curTime;
            if (timeDiff < 0 || timeDiff > this.scrollTime) continue;
            
            const progress = 1.0 - (timeDiff / this.scrollTime);
            const yTop = this.getNotePosition(0, progress).y;
            const xL = this.getNotePosition(0, progress).x;
            const xR = this.getNotePosition(6, progress).x;
            
            this.ctx.beginPath();
            this.ctx.moveTo(xL, yTop);
            this.ctx.lineTo(xR, yTop);
            this.ctx.stroke();
        }

        // 5. Active line hit glows
        for (let i = 0; i < 6; i++) {
            if (this.lineGlows[i] > 0) {
                this.lineGlows[i] -= 0.08;
                const posL = this.getNotePosition(i, 1.0);
                const posTop = this.getNotePosition(i, 0.5); // Bottom half glow
                
                this.ctx.beginPath();
                this.ctx.moveTo(posTop.x, posTop.y);
                this.ctx.lineTo(posTop.x + posTop.width, posTop.y);
                this.ctx.lineTo(posL.x + posL.width, this.bottomY);
                this.ctx.lineTo(posL.x, this.bottomY);
                this.ctx.closePath();
                
                const alpha = this.lineGlows[i] * 0.16;
                this.ctx.fillStyle = `rgba(140, 140, 255, ${alpha})`;
                this.ctx.fill();
            }
        }

        // 6. Judgment Line Neon Beam
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(pBL.x - 25, this.bottomY);
        this.ctx.lineTo(pBR.x + 25, this.bottomY);
        this.ctx.lineWidth = 6.5;
        this.ctx.strokeStyle = 'rgba(235, 235, 255, 0.95)';
        this.ctx.shadowBlur = 16;
        this.ctx.shadowColor = '#ffffff';
        this.ctx.stroke();
        this.ctx.restore();
    }

    drawRoundRect(x, y, w, h, r) {
        r = Math.max(0, Math.min(r, w / 2, h / 2));
        if (this.ctx.roundRect) {
            this.ctx.beginPath();
            this.ctx.roundRect(x, y, w, h, r);
            this.ctx.closePath();
        } else {
            this.ctx.beginPath();
            this.ctx.moveTo(x + r, y);
            this.ctx.arcTo(x + w, y, x + w, y + h, r);
            this.ctx.arcTo(x + w, y + h, x, y + h, r);
            this.ctx.arcTo(x, y + h, x, y, r);
            this.ctx.arcTo(x, y, x + w, y, r);
            this.ctx.closePath();
        }
    }

    drawNotes() {
        const currentTime = this.getElapsedTime();
        
        for (let note of this.activeNotes) {
            const holdEndTime = note.type === 'hold' ? (note.time + note.duration) : note.time;
            
            if (currentTime > holdEndTime + 0.5) {
                continue;
            }
            
            if (note.type !== 'hold' && note.hit) {
                continue;
            }
            
            let tStart = 0;
            let tEnd = 0;
            let isRenderable = false;
            
            if (note.type === 'hold') {
                if (note.missed) {
                    tStart = 1.0 - (note.time - currentTime) / this.scrollTime;
                    tEnd = 1.0 - ((note.time + note.duration) - currentTime) / this.scrollTime;
                } else if (note.hit && note.holding) {
                    tStart = 1.0;
                    tEnd = 1.0 - ((note.time + note.duration) - currentTime) / this.scrollTime;
                } else {
                    tStart = 1.0 - (note.time - currentTime) / this.scrollTime;
                    tEnd = 1.0 - ((note.time + note.duration) - currentTime) / this.scrollTime;
                }
                
                if (tEnd < 1.0 && tStart > 0) {
                    isRenderable = true;
                }
            } else {
                const timeDiff = note.time - currentTime;
                tStart = 1.0 - (timeDiff / this.scrollTime);
                if (tStart >= 0 && tStart <= 1.0) {
                    isRenderable = true;
                }
            }
            
            if (!isRenderable) continue;
            
            this.ctx.save();
            
            if (note.type !== 'hold') {
                const pos = this.getNotePosition(note.lane, tStart);
                const noteHeight = 14 * tStart * tStart + 5; 
                const radius = Math.max(2, 6 * tStart); 
                
                this.ctx.shadowBlur = 10 * tStart + 2;
                this.ctx.shadowColor = LANE_COLORS[note.type];
                
                if (note.type === 'tap') {
                    const grad = this.ctx.createLinearGradient(pos.x, pos.y - noteHeight / 2, pos.x, pos.y + noteHeight / 2);
                    grad.addColorStop(0, '#75c5ff');
                    grad.addColorStop(0.3, '#358cff');
                    grad.addColorStop(1, '#004eb3');
                    
                    this.ctx.fillStyle = grad;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = '#ffffff';
                    this.ctx.lineWidth = 1.8 * tStart + 0.5;
                    this.ctx.beginPath();
                    this.ctx.moveTo(pos.x + 3, pos.y);
                    this.ctx.lineTo(pos.x + pos.width - 3, pos.y);
                    this.ctx.stroke();

                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
                    this.ctx.lineWidth = 1.2;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.stroke();
                } 
                else if (note.type === 'critical') {
                    const grad = this.ctx.createLinearGradient(pos.x, pos.y - noteHeight / 2, pos.x, pos.y + noteHeight / 2);
                    grad.addColorStop(0, '#fff3a8');
                    grad.addColorStop(0.3, '#ffcc00');
                    grad.addColorStop(1, '#cc8800');
                    
                    this.ctx.fillStyle = grad;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = '#ffffff';
                    this.ctx.lineWidth = 2.2 * tStart + 0.5;
                    this.ctx.beginPath();
                    this.ctx.moveTo(pos.x + 3, pos.y);
                    this.ctx.lineTo(pos.x + pos.width - 3, pos.y);
                    this.ctx.stroke();

                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
                    this.ctx.lineWidth = 1.5;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.stroke();
                }
                else if (note.type === 'flick') {
                    const grad = this.ctx.createLinearGradient(pos.x, pos.y - noteHeight / 2, pos.x, pos.y + noteHeight / 2);
                    grad.addColorStop(0, '#ff9ed9');
                    grad.addColorStop(0.3, '#ff47b6');
                    grad.addColorStop(1, '#b30071');
                    
                    this.ctx.fillStyle = grad;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
                    this.ctx.lineWidth = 1.2;
                    this.drawRoundRect(pos.x, pos.y - noteHeight / 2, pos.width, noteHeight, radius);
                    this.ctx.stroke();
                    
                    const arrowY = pos.y - noteHeight - 10 * tStart;
                    const arrowCenter = pos.x + pos.width / 2;
                    const arrowWidth = 10 * tStart + 3;
                    const arrowHeight = 5 * tStart + 2;
                    
                    this.ctx.save();
                    this.ctx.shadowBlur = 8;
                    this.ctx.shadowColor = LANE_COLORS.flick;
                    this.ctx.strokeStyle = '#ffffff';
                    this.ctx.lineWidth = 3.5 * tStart + 1;
                    this.ctx.lineCap = 'round';
                    this.ctx.lineJoin = 'round';
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(arrowCenter - arrowWidth, arrowY);
                    this.ctx.lineTo(arrowCenter, arrowY - arrowHeight);
                    this.ctx.lineTo(arrowCenter + arrowWidth, arrowY);
                    this.ctx.stroke();

                    this.ctx.beginPath();
                    this.ctx.moveTo(arrowCenter - arrowWidth, arrowY + arrowHeight + 2);
                    this.ctx.lineTo(arrowCenter, arrowY + 2);
                    this.ctx.lineTo(arrowCenter + arrowWidth, arrowY + arrowHeight + 2);
                    this.ctx.stroke();
                    
                    this.ctx.restore();
                }
            } 
            else {
                const startProgress = Math.max(0, Math.min(1.0, tStart));
                const endProgress = Math.max(0, Math.min(1.0, tEnd));
                
                const posStart = this.getNotePosition(note.lane, startProgress);
                const posEnd = this.getNotePosition(note.lane, endProgress);
                
                this.ctx.beginPath();
                this.ctx.moveTo(posStart.x, posStart.y);
                this.ctx.lineTo(posStart.x + posStart.width, posStart.y);
                this.ctx.lineTo(posEnd.x + posEnd.width, posEnd.y);
                this.ctx.lineTo(posEnd.x, posEnd.y);
                this.ctx.closePath();
                
                const trailGrad = this.ctx.createLinearGradient(0, posStart.y, 0, posEnd.y);
                
                if (note.missed) {
                    trailGrad.addColorStop(0, 'rgba(130, 130, 130, 0.22)');
                    trailGrad.addColorStop(1, 'rgba(80, 80, 80, 0.08)');
                    this.ctx.fillStyle = trailGrad;
                    this.ctx.fill();
                    
                    this.ctx.save();
                    this.ctx.strokeStyle = 'rgba(150, 150, 150, 0.4)';
                    this.ctx.lineWidth = 1.5;
                    this.ctx.beginPath();
                    this.ctx.moveTo(posStart.x, posStart.y);
                    this.ctx.lineTo(posEnd.x, posEnd.y);
                    this.ctx.stroke();
                    this.ctx.beginPath();
                    this.ctx.moveTo(posStart.x + posStart.width, posStart.y);
                    this.ctx.lineTo(posEnd.x + posEnd.width, posEnd.y);
                    this.ctx.stroke();
                    this.ctx.restore();
                } else {
                    trailGrad.addColorStop(0, 'rgba(85, 255, 136, 0.42)');
                    trailGrad.addColorStop(1, 'rgba(30, 150, 80, 0.12)');
                    this.ctx.fillStyle = trailGrad;
                    this.ctx.fill();
                    
                    this.ctx.save();
                    this.ctx.strokeStyle = LANE_COLORS.hold;
                    this.ctx.lineWidth = 2.5 * startProgress + 0.5;
                    this.ctx.shadowBlur = 8;
                    this.ctx.shadowColor = LANE_COLORS.hold;
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(posStart.x, posStart.y);
                    this.ctx.lineTo(posEnd.x, posEnd.y);
                    this.ctx.stroke();
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(posStart.x + posStart.width, posStart.y);
                    this.ctx.lineTo(posEnd.x + posEnd.width, posEnd.y);
                    this.ctx.stroke();
                    
                    this.ctx.restore();
                }
                
                if (!note.hit && startProgress >= 0 && startProgress < 1.0) {
                    const noteHeight = 14 * startProgress * startProgress + 5;
                    const radius = Math.max(2, 6 * startProgress);
                    
                    const startGrad = this.ctx.createLinearGradient(posStart.x, posStart.y - noteHeight / 2, posStart.x, posStart.y + noteHeight / 2);
                    startGrad.addColorStop(0, note.missed ? '#e0e0e0' : '#a3ffc2');
                    startGrad.addColorStop(0.3, note.missed ? '#9e9e9e' : '#3eff75');
                    startGrad.addColorStop(1, note.missed ? '#555555' : '#00b333');
                    
                    this.ctx.fillStyle = startGrad;
                    this.drawRoundRect(posStart.x, posStart.y - noteHeight / 2, posStart.width, noteHeight, radius);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
                    this.ctx.lineWidth = 1.2;
                    this.drawRoundRect(posStart.x, posStart.y - noteHeight / 2, posStart.width, noteHeight, radius);
                    this.ctx.stroke();
                }
                
                if (endProgress >= 0 && endProgress < 1.0) {
                    const endHeight = 14 * endProgress * endProgress + 5;
                    const endRadius = Math.max(2, 6 * endProgress);
                    
                    const endGrad = this.ctx.createLinearGradient(posEnd.x, posEnd.y - endHeight / 2, posEnd.x, posEnd.y + endHeight / 2);
                    endGrad.addColorStop(0, note.missed ? '#e0e0e0' : '#a3ffc2');
                    endGrad.addColorStop(0.3, note.missed ? '#9e9e9e' : '#3eff75');
                    endGrad.addColorStop(1, note.missed ? '#555555' : '#00b333');
                    
                    this.ctx.fillStyle = endGrad;
                    this.drawRoundRect(posEnd.x, posEnd.y - endHeight / 2, posEnd.width, endHeight, endRadius);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
                    this.ctx.lineWidth = 1.2;
                    this.drawRoundRect(posEnd.x, posEnd.y - endHeight / 2, posEnd.width, endHeight, endRadius);
                    this.ctx.stroke();
                }
            }
            this.ctx.restore();
        }
    }

    drawRipples() {
        for (let i = this.ripples.length - 1; i >= 0; i--) {
            const r = this.ripples[i];
            r.radius += r.speed;
            r.alpha -= 0.04;
            
            if (r.alpha <= 0) {
                this.ripples.splice(i, 1);
                continue;
            }

            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
            this.ctx.strokeStyle = `rgba(180, 230, 255, ${r.alpha})`;
            this.ctx.lineWidth = 3.8;
            this.ctx.shadowBlur = 10;
            this.ctx.shadowColor = '#b4e6ff';
            this.ctx.stroke();

            this.ctx.beginPath();
            this.ctx.arc(r.x, r.y, r.radius * 0.6, 0, Math.PI * 2);
            this.ctx.strokeStyle = `rgba(140, 190, 255, ${r.alpha * 0.6})`;
            this.ctx.lineWidth = 2.0;
            this.ctx.stroke();
            this.ctx.restore();
        }
    }

    drawParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.25;
            p.alpha -= 0.04;
            
            if (p.alpha <= 0) {
                this.particles.splice(i, 1);
                continue;
            }

            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(255, 255, 255, ${p.alpha})`;
            this.ctx.shadowBlur = 5;
            this.ctx.shadowColor = '#ffffff';
            this.ctx.fill();
            this.ctx.restore();
        }
    }

    loop(time) {
        if (!this.isPlaying || this.isPaused) return;

        // Clear Canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        const currentTime = this.getElapsedTime();

        // ----------------------------------------------------
        // Real-time active input state resolution
        // ----------------------------------------------------
        this.isLaneHeld.fill(false);

        // 1. Resolve mobile multi-touch inputs
        if (Object.keys(this.currentTouches).length > 0) {
            for (let id in this.currentTouches) {
                const touch = this.currentTouches[id];
                // Use holding Y-tolerance (wider check) for active hold notes
                const lane = this.getLaneFromCoordinates(touch.x, touch.y, true);
                if (lane !== null) {
                    this.isLaneHeld[lane] = true;
                    this.lineGlows[lane] = 0.8;
                }
            }
        }

        // 2. Resolve mouse holds (PC)
        if (this.mouseStartPoint) {
            const lane = this.getLaneFromCoordinates(this.mouseStartPoint.x, this.mouseStartPoint.y, true);
            if (lane !== null) {
                this.isLaneHeld[lane] = true;
                this.lineGlows[lane] = 0.8;
            }
        }

        // 3. Resolve keyboard holds
        for (let i = 0; i < 6; i++) {
            if (this.keyboardLanesHeld[i]) {
                this.isLaneHeld[i] = true;
                this.lineGlows[i] = 0.8;
            }
        }
        // ----------------------------------------------------

        // Note state update & Hold Note release checks
        for (let note of this.activeNotes) {
            if (note.missed) continue;

            // Miss check for normal notes
            if (note.type !== 'hold' && !note.hit && currentTime > note.time + this.goodWindow) {
                note.missed = true;
                this.triggerMiss();
            }

            // Miss check for hold notes (never initiated)
            if (note.type === 'hold' && !note.hit && currentTime > note.time + this.goodWindow) {
                note.missed = true;
                this.triggerMiss();
            }

            // Mid-hold release checks
            if (note.type === 'hold' && note.hit && !note.missed && !note.completed) {
                const holdEndTime = note.time + note.duration;
                if (currentTime < holdEndTime) {
                    const isHeld = this.autoPlay || this.isLaneHeld[note.lane];
                    if (!isHeld) {
                        // Release leniency check: 150ms before the end is allowed!
                        if (holdEndTime - currentTime <= 0.15) {
                            note.holding = false;
                            note.completed = true;
                            this.stopHoldSfx(note);
                        } else {
                            note.missed = true;
                            note.holding = false;
                            this.triggerMiss(); // Trigger MISS judgment
                            this.stopHoldSfx(note);
                        }
                    } else {
                        this.spawnHoldSparks(note.lane);
                    }
                } else {
                    note.holding = false;
                    note.completed = true;
                    this.stopHoldSfx(note);
                }
            }

            // Gold (Critical) Note "touch-to-hit" bypass logic:
            // If a finger is down on the track when it reaches perfect window, trigger auto-clear
            if (note.type === 'critical' && !note.hit && !note.missed) {
                const timeDiff = currentTime - note.time;
                if (Math.abs(timeDiff) <= this.perfectWindow && (this.isLaneHeld[note.lane] || this.autoPlay)) {
                    note.hit = true;
                    this.playHitSound('critical');
                    this.handleRating(Math.abs(timeDiff), note);
                    this.spawnRipple(note.lane, 'critical');
                }
            }

            // Auto Play Engine
            if (this.autoPlay) {
                if (note.type !== 'critical' && !note.hit && currentTime >= note.time) {
                    note.hit = true;
                    this.triggerHitAuto(note.lane, note.type);
                    if (note.type === 'hold') {
                        note.holding = true;
                        this.playHoldSfx(note);
                    }
                }
            }
        }

        // Render game components
        this.drawBackground();
        this.drawTrack();
        this.drawNotes();
        this.drawRipples();
        this.drawParticles();

        // Check for stage clear
        if (currentTime > this.songDuration) {
            this.isPlaying = false;
            this.showResult();
            return;
        }

        requestAnimationFrame((time) => this.loop(time));
    }
}

// Initial Launch
window.addEventListener('DOMContentLoaded', () => {
    window.game = new EchoesGame();
});

// Expose dynamic Quit button for pywebview desktop launcher
window.addEventListener('pywebviewready', () => {
    console.log("pywebview is ready!");
    const menuContent = document.querySelector('.main-menu-content');
    if (menuContent) {
        if (!document.getElementById('desktop-quit-btn')) {
            const quitBtn = document.createElement('button');
            quitBtn.id = 'desktop-quit-btn';
            quitBtn.className = 'live-select-btn';
            quitBtn.style.marginTop = '15px';
            quitBtn.style.background = 'rgba(255, 0, 127, 0.15)';
            quitBtn.style.border = '1px solid rgba(255, 0, 127, 0.4)';
            quitBtn.style.boxShadow = '0 0 15px rgba(255, 0, 127, 0.2)';
            quitBtn.innerHTML = `
                <span class="btn-text" style="color: #ff007f;">QUIT GAME</span>
                <span class="btn-subtext" style="color: rgba(255, 0, 127, 0.6);">關閉電腦客戶端</span>
            `;
            quitBtn.addEventListener('click', () => {
                if (window.pywebview && window.pywebview.api) {
                    window.pywebview.api.quit_game();
                }
            });
            menuContent.appendChild(quitBtn);
        }
    }
});
